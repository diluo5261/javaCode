create view v_v2 as
select `canal_tsdb`.`t_user`.`id` AS `id`, `canal_tsdb`.`t_user`.`name` AS `name`
from `canal_tsdb`.`t_user`;

